# Chrome im Terbium-Fenster

## 1. NAS-Projekt

Im UGREEN Container Manager ein neues Compose-Projekt anlegen.
`nas/compose.yaml` und eine Kopie von `nas/.env.example` namens `.env` in denselben Projektordner legen.
In `.env` ein eigenes Passwort als CHROME_PASSWORD eintragen; keine spitzen Klammern erforderlich.
Wenn die Oberfläche keine .env-Datei unterstützt, den PASSWORD-Wert in der Compose-Datei vollständig durch ein eigenes, in Anführungszeichen gesetztes Passwort ersetzen.
PUID/PGID 1000 sind Vorgaben und müssen bei abweichender NAS-Benutzer-ID angepasst werden.
Projekt starten. Port 7777 muss frei sein; die NAS-IP muss 192.168.178.168 sein.

## 2. Chrome direkt prüfen

https://192.168.178.168:7777/ im normalen Browser öffnen.
Das Container-Zertifikat ist selbstsigniert. Nach Prüfung der lokalen Adresse die Zertifikatswarnung akzeptieren.
Benutzer: admin. Passwort: der Wert aus deiner .env.
Das zunächst außerhalb von Terbium erledigen, damit Zertifikats- und Anmeldefehler nicht im eingebetteten Fenster verschwinden.
Browserprofil und Downloads liegen dauerhaft im Projektordner chrome-config.

## 3. GitHub und Terbium

Den Inhalt des Ordners terbium-app-repo in ein neues öffentliches Repo namens terbium-app-repo unter malschaun7 hochladen, Branch main.
Den Ordner nas und die .env NICHT hochladen.
In Terbiums App-Store/Repo-Verwaltung ein eigenes Repository hinzufügen.
Für v2 die Raw-Adresse zur manifest.json verwenden; für ältere Versionen die Raw-Adresse zur apps.json. Details im Repo-README.
Chrome NAS installieren und starten.

## Grenzen und Fehlerdiagnose

Hier wurden JSON, YAML, Portzuordnung und Archiv geprüft. Der Start auf deinem NAS und die Einbettung in deine Terbium-Version konnten nicht getestet werden.
Ein öffentlicher GitHub-App-Eintrag macht das NAS nicht öffentlich erreichbar.
Bei einem leeren Fenster zuerst die direkte Chrome-Adresse prüfen. Browser können lokale Netzwerkzugriffe, Basic-Auth in eingebetteten Fenstern oder Einbettung durch CSP/frame-ancestors/X-Frame-Options blockieren. Eine Zertifikatsausnahme allein löst diese Sperren nicht.
Wenn Chrome direkt funktioniert, aber in Terbium nicht: Browserkonsole prüfen und die Fehlermeldung weitergeben. Dann lässt sich die passende lokale HTTPS-/Reverse-Proxy-Konfiguration für deine Terbium-Adresse erstellen.
Mehrere Terbium-Benutzer teilen mit dieser Konfiguration dasselbe Chrome-Profil und dieselbe Sitzung.

## Updates

latest bedeutet das zuletzt heruntergeladene Image. Für Updates im Container Manager das Image erneut herunterladen und das Projekt/den Container neu erstellen; den Ordner chrome-config behalten.
Kein Dockerfile erforderlich. Keine Portfreigabe am Router für diese lokale Konfiguration.

## Quellen

https://docs.linuxserver.io/images/docker-chrome/
https://github.com/TerbiumOS/app-repo
https://github.com/TerbiumOS/tb-repo
